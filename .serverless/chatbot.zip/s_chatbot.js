
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'lzwdct',
  applicationName: 'chatbot',
  appUid: '0jKf1zcp1jKwSKmhwG',
  orgUid: 'GyhY7Vjng34pjgpJJk',
  deploymentUid: 'b1386cca-ebd3-4c50-b845-f96283c22c8e',
  serviceName: 'chatbot',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.13',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'chatbot-dev-chatbot', timeout: 6 };

try {
  const userHandler = require('./chatbot.js');
  module.exports.handler = serverlessSDK.handler(userHandler.chatbot, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}